<?php

/*
Widget Name: AlphaLeonisAddons Instagram Feed
Description: Facebook feed.
Author: Alpha Leonis
Author URI: http://alphaleonis.pl
*/

namespace AlphaLeonisAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use AlphaLeonisAddons\Api\InstagramScraper;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class TextEditor extends Widget_Base
{
	public function get_name() {
        return 'ala-text-editor';
    }

    public function get_title() {
        return __('Text editor', 'al-el-addons');
    }

    public function get_icon() {
        return 'eicon-text-area';
    }

    public function get_categories() {
        return array('alphaleonis-addons');
    }

    public function get_script_depends() {
        return [];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'section_editor',
            [
                'label' => __( 'Text Editor', 'elementor' ),
            ]
        );

        $this->add_control(
            'editor',
            [
                'label' => '',
                'type' => Controls_Manager::WYSIWYG,
                'default' => __( 'I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'elementor' ),
            ]
        );
    }

    protected function render() {
        $editor_content = $this->get_settings( 'editor' );
        $editor_content = $this->parse_text_editor( $editor_content );
        ?>

        <div class="ala-text-editor elementor-clearfix">
            <?php echo $editor_content; ?>
        </div>
        
        <?php
    }
}

<?php

/*
Widget Name: AlphaLeonisAddons Instagram Feed
Description: Facebook feed.
Author: Alpha Leonis
Author URI: http://alphaleonis.pl
*/

namespace AlphaLeonisAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use AlphaLeonisAddons\Api\InstagramScraper;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class InstagramFeed extends Widget_Base
{
	public function get_name() {
        return 'ala-instagram-feed';
    }

    public function get_title() {
        return __('Instagram feed', 'al-el-addons');
    }

    public function get_icon() {
        return 'eicon-photo-library';
    }

    public function get_categories() {
        return array('alphaleonis-addons');
    }

    public function get_script_depends() {
        return [];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_heading',
            [
                'label' => __('Instagram feed', 'al-el-addons'),
            ]
        );

        $this->add_control(
            'username',
            [
                'type' => Controls_Manager::TEXT,
                'label' => __('Instagram username', 'al-el-addons'),
                'label_block' => true
            ]
        );

        $this->add_control(
            'images_count',
            [
                'type' => Controls_Manager::NUMBER,
                'label' => __('Number of posts', 'al-el-addons'),
                'label_block' => true,
                'default' => 8,
            ]
        );

        $this->add_control(
            'columns_count',
            [
                'type' => Controls_Manager::NUMBER,
                'label' => __('Number of columns', 'al-el-addons'),
                'label_block' => true,
                'default' => 4,
                'selectors' => [
                    '{{WRAPPER}} .al-cards-container > .al-card-wrapper' => 'flex: 0 1 calc(100% / {{VALUE}});',
                ],
            ]
        );

        $this->add_control(
            'limit_content_length',
            [
                'type' => Controls_Manager::TEXT,
                'label' => __('Content characters limit', 'al-el-addons'),
                'label_block' => true,
                'description' => __('Leave empty to disable', 'al-el-addons'),
            ]
        );

        $this->add_control(
            'display_date',
            [
                'label' => __('Display post date?', 'al-el-addons'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'al-el-addons'),
                'label_off' => __('No', 'al-el-addons'),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'display_message',
            [
                'label' => __('Display post message?', 'al-el-addons'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'al-el-addons'),
                'label_off' => __('No', 'al-el-addons'),
                'return_value' => 'yes',
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'display_likes',
            [
                'label' => __('Display post likes?', 'al-el-addons'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'al-el-addons'),
                'label_off' => __('No', 'al-el-addons'),
                'return_value' => 'yes',
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'display_comments',
            [
                'label' => __('Display post comments?', 'al-el-addons'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'al-el-addons'),
                'label_off' => __('No', 'al-el-addons'),
                'return_value' => 'yes',
                'default' => 'yes'
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_heading2',
            [
                'label' => __('Design', 'al-el-addons'),
                'tab' => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_control(
            'vertical_gap',
            [
                'type' => Controls_Manager::SLIDER,
                'label' => __('Vertical gap', 'al-el-addons'),
                'label_block' => true,
                'description' => __('Space between articles', 'al-el-addons'),
                'size_units' => [ 'px', 'em' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .al-cards-container > .al-card-wrapper' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .al-cards-container' => 'margin-left: -{{SIZE}}{{UNIT}}; margin-right: -{{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'horizontal_gap',
            [
                'type' => Controls_Manager::SLIDER,
                'label' => __('Horizontal gap', 'al-el-addons'),
                'label_block' => true,
                'description' => __('Space between article rows', 'al-el-addons'),
                'size_units' => [ 'px', 'em' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .al-cards-container > .al-card-wrapper' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .al-cards-container' => 'margin-bottom: -{{SIZE}}{{UNIT}};'
                ],
            ]
        );

        $this->add_control(
            'card_padding',
            [
                'label'      => __( 'Card padding', 'al-el-addons' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .al-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'description_padding',
            [
                'label'      => __( 'Description padding', 'al-el-addons' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .al-card-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'bg_color',
            [
                'label' => __('Background color', 'al-el-addons'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .al-card' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'reactions_text_align',
            [
                'label' => __( 'Reactions alignment', 'al-el-addons' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'al-el-addons' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'al-el-addons' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'al-el-addons' ),
                        'icon' => 'fa fa-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'al-el-addons' ),
                        'icon' => 'fa fa-align-justify',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .al-card .al-card-reactions' => 'text-align: {{VALUE}};',
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_design_image',
            [
                'label' => __( 'Image', 'al-el-addons' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'image_aspect_ratio',
            [
                'label' => __( 'Aspect ratio', 'al-el-addons' ),
                'type' => Controls_Manager::SELECT,
                'default' => '100%',
                'options' => [
                    '56.25%'    =>  '16:9',
                    '62.5%'     =>  '8:5',
                    '66.66%'    =>  '3:2',
                    '75%'       =>  '4:3',
                    '100%'      =>  '1:1'
                ],
                'selectors'  => [
                    '{{WRAPPER}} .al-card-thumbnail' => 'padding-bottom: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'img_border_radius',
            [
                'label'      => __( 'Border Radius', 'al-el-addons' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .al-card-thumbnail' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'image_spacing',
            [
                'label'     => __( 'Spacing', 'al-el-addons' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .al-card-thumbnail'   => 'margin-bottom: {{SIZE}}{{UNIT}}',
                ],
                'default'   => [
                    'size' => 20,
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_date',
            [
                'label' => __( 'Date', 'al-el-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'display_date' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'date_color',
            [
                'label' => __('Date color', 'al-el-addons'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .al-cards-container .al-card-date' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'date_text_align',
            [
                'label' => __( 'Alignment', 'al-el-addons' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'al-el-addons' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'al-el-addons' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'al-el-addons' ),
                        'icon' => 'fa fa-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'al-el-addons' ),
                        'icon' => 'fa fa-align-justify',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .al-cards-container .al-card-date' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'date_typography',
                'label' => __( 'Date typography', 'al-el-addons' ),
                'selector' => '{{WRAPPER}} .al-cards-container .al-card-date',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_text',
            [
                'label' => __( 'Content', 'al-el-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'display_message' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => __('Color', 'al-el-addons'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .al-card-content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_text_align',
            [
                'label' => __( 'Alignment', 'al-el-addons' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'al-el-addons' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'al-el-addons' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'al-el-addons' ),
                        'icon' => 'fa fa-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'al-el-addons' ),
                        'icon' => 'fa fa-align-justify',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .al-card-content' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'label' => __( 'Content typography', 'al-el-addons' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_3,
                'selector' => '{{WRAPPER}} .al-card-content',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_likes',
            [
                'label' => __( 'Likes', 'al-el-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'display_likes' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'likes_icon_color',
            [
                'label' => __('Icon color', 'al-el-addons'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .al-cards-container .al-card-likes > i.fa' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'likes_text_color',
            [
                'label' => __('Text color', 'al-el-addons'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .al-cards-container .al-card-likes' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'likes_icon',
            [
                'label' => __( 'Icon', 'al-el-addons' ),
                'type' => Controls_Manager::ICON,
                'label_block' => true,
                'default' => 'fa fa-thumbs-up',
            ]
        );

        $this->add_control(
            'text_padding',
            [
                'label' => __( 'Padding', 'al-el-addons' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default' => [
                    'top' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'right' => '0',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .al-cards-container .al-card-likes' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}'
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_comments',
            [
                'label' => __( 'Comments', 'al-el-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'display_comments' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'comments_icon_color',
            [
                'label' => __('Icon color', 'al-el-addons'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .al-cards-container .al-card-comments > i.fa' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'comments_text_color',
            [
                'label' => __('Text color', 'al-el-addons'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .al-cards-container .al-card-comments' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'comments_icon',
            [
                'label' => __( 'Icon', 'al-el-addons' ),
                'type' => Controls_Manager::ICON,
                'label_block' => true,
                'default' => 'fa fa-comment',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {

        $settings = $this->get_settings();

        $instagram = new InstagramScraper;
        $images = $instagram->getUserImages($settings['username'], $settings['images_count']);

        ?>

        <section class="al-cards-container al-instagram-feed">
        
        <?php foreach ($images as $image): ?>

            <div class="al-card-wrapper">
                <article class="al-card al-instagram-feed-post">
                    <a href="<?php echo $image['link'] ?>">
                        <div class="al-card-thumbnail" style="background-image: url('<?php echo $image['large'] ?>');"></div>
                    </a>
                    <div class="al-card-body">
                        <?php if ($settings['display_date']): ?>
                            <p class="al-card-date"><?php echo \AlphaLeonisAddons\Helpers\Date::toPolish(date("F j, Y, H:i", $image['date'])) ?></p>
                        <?php endif ?>
                        <?php if ($settings['display_message']): ?>
                        <p class="al-card-content">
                            <?php if (!empty($settings['limit_content_length']) && !empty($image['description'])): ?>
                                <?php echo ala_truncate($image['description'], $settings['limit_content_length']) ?><br>
                                <a href="<?php echo $image['link'] ?>">Czytaj więcej</a>
                            <?php else: ?>
                                <?php echo $image['description'] ?>
                            <?php endif ?>
                        </p>
                        <?php endif ?>
                        <?php if ($settings['display_likes'] || $settings['display_comments']): ?>
                            <div class="al-card-reactions">
                            <?php if ($settings['display_likes']): ?>
                                <span class="al-card-likes">
                                    <i class="<?php echo esc_attr( $settings['likes_icon'] ); ?>"></i> <?php echo $image['likes'] ?>
                                </span>
                            <?php endif ?>
                            <?php if ($settings['display_comments']): ?>
                                <span class="al-card-comments">
                                    <i class="<?php echo esc_attr( $settings['comments_icon'] ); ?>"></i> <?php echo $image['comments'] ?>
                                </span>
                            <?php endif ?>
                            </div>
                        <?php endif ?>
                    </div>
                </article>
            </div>

        <?php endforeach ?>

        </section>

        <?php
    }
}
